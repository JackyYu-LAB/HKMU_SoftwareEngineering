import SwiftUI
import FirebaseFirestore


struct OrderDetailView: View {
    let order: Order
    let onPay: () -> Void
    
    private var subtotal: Double {
        order.items.reduce(0) { $0 + ($1.menuItem.price * Double($1.quantity)) }
    }
    
    var body: some View {
        NavigationStack {
            List {
                Section("Delivery Address") {
                    Text(order.deliveryAddress)
                        .font(.body)
                }
                
                Section("Order Detail") {
                    ForEach(order.items) { item in
                        VStack(alignment: .leading, spacing: 8) {
                            HStack {
                                Text(item.menuItem.name)
                                    .font(.headline)
                                Spacer()
                                Text("Qty: \(item.quantity) × $\(item.menuItem.price, specifier: "%.2f")")
                                    .font(.subheadline)
                                    .foregroundColor(.secondary)
                            }
                            
                            if !item.menuItem.description.isEmpty {
                                Text(item.menuItem.description)
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }
                        }
                        .padding(.vertical, 4)
                    }
                }
                
                Section {
                    HStack {
                        Text("Subtotal")
                        Spacer()
                        Text("$\(subtotal, specifier: "%.2f")")
                            .foregroundColor(.secondary)
                    }
                    
                    HStack {
                        Text("Delivery Fee")
                        Spacer()
                        Text("$\(order.deliveryFee, specifier: "%.2f")")
                            .foregroundColor(.secondary)
                    }
                    
                    HStack {
                        Text("Total")
                            .font(.title3)
                            .fontWeight(.bold)
                        Spacer()
                        Text("$\(order.totalPrice, specifier: "%.2f")")
                            .font(.largeTitle)
                            .fontWeight(.bold)
                            .foregroundColor(.blue)
                    }
                }
                
                if order.status == "pending" {
                    Section {
                        Button("Proceed to Payment") {
                            onPay()
                        }
                        .frame(maxWidth: .infinity)
                        .buttonStyle(.borderedProminent)
                        .controlSize(.large)
                        .tint(.blue)
                    }
                    .listRowBackground(Color.clear)
                }
            }
            .navigationTitle("Order Checkout")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}
