import SwiftUI
import FirebaseFirestore
import Combine


struct RestaurantCardView: View {
    let restaurant: Restaurant
    let addToCart: (MenuItem, String) -> Void
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text(restaurant.name)
                    .font(.title2).bold()
                Text("• \(restaurant.cuisine)")
                    .foregroundColor(.secondary)
                Spacer()
                HStack(spacing: 4) {
                    Image(systemName: "star.fill").foregroundColor(.yellow)
                    Text(String(format: "%.1f", restaurant.rating))
                }
            }
            
            ForEach(restaurant.menuItems.filter { $0.isAvailable }) { item in
                HStack {
                    if let url = item.imageURL, let imageURL = URL(string: url) {
                        AsyncImage(url: imageURL) { image in
                            image.resizable().scaledToFill()
                        } placeholder: {
                            Color.gray.opacity(0.3)
                        }
                        .frame(width: 60, height: 60)
                        .cornerRadius(8)
                    }
                    
                    VStack(alignment: .leading) {
                        Text(item.name).font(.headline)
                        Text(item.description)
                            .font(.caption)
                            .foregroundColor(.secondary)
                            .lineLimit(2)
                        Text("HK$\(item.price, specifier: "%.2f")")
                            .font(.subheadline).bold()
                    }
                    Spacer()
                    Button("Add") {
                        addToCart(item, restaurant.name)
                    }
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                }
                .padding(.vertical, 4)
            }
        }
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(16)
        .shadow(radius: 2)
    }
}
