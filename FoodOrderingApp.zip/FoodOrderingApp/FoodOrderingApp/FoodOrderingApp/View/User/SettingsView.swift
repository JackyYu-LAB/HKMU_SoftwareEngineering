import SwiftUI
import FirebaseAuth

struct SettingsView: View {
    var body: some View {
        VStack {
            Text("Setting")
                .font(.largeTitle)
                .padding()
            
            Button("Logout") {
                do {
                    try Auth.auth().signOut()
                } catch let signOutError as NSError {
                    print("Logout error: \(signOutError)")
                }
            }
            .padding()
            .background(Color.red)
            .foregroundColor(.white)
            .cornerRadius(8)
        }
    }
}

#Preview {
    SettingsView()
}
