import SwiftUI
import FirebaseFirestore
import FirebaseAuth
import MapKit

struct ContentView: View {
    @State private var restaurants: [Restaurant] = []
    @State private var cart: [CartItem] = []
    @State private var address: Address = Address()
    @State private var orders: [Order] = []
    @State private var searchText: String = ""
    @State private var showAlert: Bool = false
    @State private var alertMessage: String = ""
    @State private var showPayment: Bool = false
    @State private var couponCode: String = ""
    @State private var finalPaymentAmount: Double = 0.0
    @State private var paymentSuccess: Bool = false
    @State private var selectedOrder: Order? = nil
    @State private var rating: Int = 5
    @State private var review: String = ""
    @State private var selectedPendingOrder: Order? = nil
    @State private var selectedOrderForDetail: Order? = nil
    @State private var tabSelection: Int = 1
    @State private var alertTitle: String = ""
    
    
    let db = Firestore.firestore()
    
    var body: some View {
        NavigationStack {
            TabView(selection: $tabSelection) {
                menuView
                    .tabItem { Label("Menu", systemImage: "menucard") }
                    .tag(1)
                
                cartView
                    .tabItem { Label("Cart", systemImage: "cart") }
                    .tag(2)
                
                ordersView
                    .tabItem { Label("Orders", systemImage: "list.bullet") }
                    .tag(3)
                
                SettingsView()
                    .tabItem { Label("Settings", systemImage: "gear") }
                    .tag(4)
            }
            .navigationTitle("Food Ordering App")
            .onAppear {
                loadOrders()
                loadSavedAddress()
                
                if restaurants.isEmpty {
                    Task {
                        await loadRestaurantsFromFirebase()
                    }
                }
            }
            .alert(alertTitle, isPresented: $showAlert) {
                Button("OK") {}
                
            } message: {
                Text(alertMessage)
            }
            .sheet(isPresented: $showPayment) {
                paymentView
            }
        }
    }
    
    private var menuView: some View {
        VStack {
            TextField("Search for Restaurants, Dishes, or Food (Optional)", text: $searchText)
                .textFieldStyle(.roundedBorder)
                .padding()
            
            ScrollView {
                LazyVStack(spacing: 16) {
                    if filteredRestaurants.isEmpty {
                        Text("Loading restaurant information...")
                            .foregroundColor(.secondary)
                            .padding()
                    } else {
                        ForEach(filteredRestaurants) { restaurant in
                            RestaurantCardView(restaurant: restaurant, addToCart: addToCart)
                                .padding(.horizontal)
                        }
                    }
                }
                .padding(.vertical)
            }
            .refreshable {
                await loadRestaurantsFromFirebase()
            }
            .onAppear {
                if restaurants.isEmpty {
                    Task {
                        await loadRestaurantsFromFirebase()
                    }
                }
            }
        }
    }
    
    private var filteredRestaurants: [Restaurant] {
        if searchText.isEmpty {
            return restaurants
        } else {
            return restaurants.filter { restaurant in
                restaurant.name.localizedCaseInsensitiveContains(searchText) ||
                restaurant.cuisine.localizedCaseInsensitiveContains(searchText) ||
                restaurant.menuItems.contains { item in
                    item.name.localizedCaseInsensitiveContains(searchText) ||
                    item.description.localizedCaseInsensitiveContains(searchText)
                }
            }
        }
    }
    
    private func addToCart(item: MenuItem, restaurantName: String) {
        if let existingIndex = cart.firstIndex(where: { cartItem in
            cartItem.menuItem.id == item.id &&
            cartItem.restaurantName == restaurantName
        }) {
            cart[existingIndex].quantity += 1
        } else {
            cart.append(CartItem(menuItem: item, quantity: 1, options: [], restaurantName: restaurantName))
        }
    }
    
    private var cartView: some View {
        VStack {
            VStack {
                Text("Delivery Address").font(.headline).padding()
                TextField("Enter address (e.g., Tsim Sha Tsui)", text: $address.street)
                    .textFieldStyle(.roundedBorder)
                    .padding(.horizontal)
                Button("Verify Address") { validateAddress() }
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(8)
                
                if address.validated {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Address: \(address.street)")
                        Text("ETA: \(address.eta) min")
                        Text("Delivery Fee: $\(address.fee, specifier: "%.2f")")
                    }
                    .foregroundColor(.green)
                    .padding()
                }
            }
            .background(Color.gray.opacity(0.1))
            .cornerRadius(10)
            .padding()
            
            if cart.isEmpty {
                Text("Your cart is empty")
                    .foregroundColor(.secondary)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                List {
                    ForEach($cart) { $item in
                        VStack(alignment: .leading) {
                            Text("Restaurant: \(item.restaurantName)")
                                .font(.subheadline)
                                .foregroundColor(.gray)
                            HStack {
                                Text(item.menuItem.name)
                                Spacer()
                                Stepper("Qty: \(item.quantity)", value: Binding(
                                    get: { item.quantity },
                                    set: { newValue in
                                        if let index = cart.firstIndex(where: { $0.id == item.id }) {
                                            var updatedItem = item
                                            updatedItem.quantity = max(0, newValue) 
                                            if updatedItem.quantity == 0 {
                                                cart.remove(at: index)
                                            } else {
                                                cart[index] = updatedItem
                                            }
                                        }
                                    }
                                ), in: 0...50)
                                Text("$\(item.menuItem.price * Double(item.quantity), specifier: "%.2f")")
                            }
                        }
                    }
                }
            }
            
            TextField("Coupon Code (optional)", text: $couponCode)
                .textFieldStyle(.roundedBorder)
                .padding(.horizontal)
            
            Text("Total: $\(totalPrice, specifier: "%.2f")")
                .font(.largeTitle)
                .fontWeight(.bold)
                .padding()
            
            Button("Place Order") {
                placeOrder()
                showPayment = true
            }
            .buttonStyle(.borderedProminent)
            .controlSize(.large)
            .padding(.horizontal)
            .disabled(cartTotalItems <= 0 || !address.validated)
            .opacity(cart.isEmpty || !address.validated ? 0.6 : 1.0)
        }
    }
    
    private var cartTotalItems: Int {
        cart.reduce(0) { $0 + $1.quantity }
    }
    
    private var totalPrice: Double {
        cart.reduce(0) { $0 + ($1.menuItem.price * Double($1.quantity)) } + address.fee
    }
    
    private func validateAddress() {
        let trimmed = address.street.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else {
            alertTitle = "Error"
            alertMessage = "Please enter a delivery address."
            showAlert = true
            return
        }
        calculateETA { eta in
            let fee = 10.0 + Double(eta) * 0.5
            address = Address(street: trimmed, validated: true, eta: eta, fee: fee)
            saveAddressToFirestore()
        }
    }
    
    private func calculateETA(completion: @escaping (Int) -> Void) {
        let geocoder = CLGeocoder()
        var userAddress = address.street.trimmingCharacters(in: .whitespacesAndNewlines)
        
        if !userAddress.localizedCaseInsensitiveContains("hong kong") {
            userAddress += ", Hong Kong"
        }
        
        geocoder.geocodeAddressString(userAddress) { placemarks, error in
            if let error = error {
                print("Geocoding error: \(error.localizedDescription)")
//                self.alertMessage = "Unable to locate address. Try adding 'Hong Kong' or using English."
//                self.showAlert = true
                completion(30)
                return
            }
            
            guard let userLocation = placemarks?.first?.location else {
//                self.alertMessage = "Address not found. Please check spelling or add 'Hong Kong'."
//                self.showAlert = true
                completion(30)
                return
            }
            if let firstRestaurant = restaurants.first {
                geocoder.geocodeAddressString(firstRestaurant.location) { placemarks, error in
                    guard let restaurantLocation = placemarks?.first?.location else {
//                        self.alertMessage = "Restaurant location error."
//                        self.showAlert = true
                        completion(30)
                        return
                    }

                    let distanceMeters = userLocation.distance(from: restaurantLocation)
                    let distanceKm = distanceMeters / 1000.0
                    let etaMinutes = Int((distanceKm / 30.0) * 60.0)
                    completion(max(etaMinutes, 15))
                }
            } else {
                completion(30)
            }
        }
    }
    
    private func placeOrder() {
        var orderTotal = totalPrice
        if !couponCode.trimmingCharacters(in: .whitespaces).isEmpty {
            orderTotal *= 0.9
        }
        finalPaymentAmount = orderTotal
        
        let newOrder = Order(
            items: cart,
            deliveryAddress: address.street,
            totalPrice: orderTotal,
            status: "pending",
            deliveryFee: address.fee,
            eta: address.eta          
        )
        orders.append(newOrder)
        saveOrdersToFirestore()
    }
    
    private func loadRestaurantsFromFirebase() async {
        do {
            let snapshot = try await db.collection("restaurants").getDocuments()
            var loaded: [Restaurant] = []
            
            for doc in snapshot.documents {
                let data = doc.data()
                let id = doc.documentID
                let name = data["name"] as? String ?? "Unknown Restaurant"
                let cuisine = data["cuisine"] as? String ?? ""
                let rating = data["rating"] as? Double ?? 4.5
                let location = data["location"] as? String ?? ""
                
                var menuItems: [MenuItem] = []
                
                if let itemsArray = data["menuItems"] as? [[String: Any]] {
                    for itemData in itemsArray {
                        let name = itemData["name"] as? String ?? ""
                        let priceRaw = itemData["price"] ?? 0.0
                        let price: Double = {
                            if let p = priceRaw as? Double { return p }
                            if let p = priceRaw as? Int { return Double(p) }
                            if let p = priceRaw as? String, let d = Double(p) { return d }
                            return 0.0
                        }()
                        let description = itemData["description"] as? String ?? ""
                        let isAvailable = itemData["isAvailable"] as? Bool ?? true
                        let imageURL = itemData["imageURL"] as? String
                        
                        let itemId = itemData["id"] as? String ?? UUID().uuidString
                        let menuItem = MenuItem(
                            name: name,
                            price: price,
                            description: description,
                            isAvailable: isAvailable,
                            imageURL: imageURL
                        )
                        menuItems.append(menuItem)
                    }
                }
                
                let restaurant = Restaurant(
                    id: id,
                    name: name,
                    cuisine: cuisine,
                    rating: rating,
                    menuItems: menuItems,
                    location: location
                )
                loaded.append(restaurant)
            }
            
            await MainActor.run {
                self.restaurants = []       
                self.restaurants = loaded
            }
            
        } catch {
            await MainActor.run {
                alertTitle = "Loading Failed"
                alertMessage = "Please check your network connection and try again after clicking the drop-down menu."
                showAlert = true
            }
        }
    }
    
    func loadOrders() {
        db.collection("orders").getDocuments { (querySnapshot, error) in
            if let error = error {
                print("Order Loading Error: \(error)")
                return
            }
            var loadedOrders: [Order] = []
            for document in querySnapshot?.documents ?? [] {
                let data = document.data()
                let id = document.documentID
                let deliveryAddress = data["deliveryAddress"] as? String ?? ""
                let totalPrice = data["totalPrice"] as? Double ?? 0.0
                let status = data["status"] as? String ?? "pending"
                var items: [CartItem] = []
                if let itemsData = data["items"] as? [[String: Any]] {
                    for itemData in itemsData {
                        let menuItem = MenuItem(
                            name: itemData["name"] as? String ?? "",
                            price: itemData["price"] as? Double ?? 0.0,
                            description: itemData["description"] as? String ?? "",
                            isAvailable: true,
                            imageURL: itemData["imageURL"] as? String
                        )
                        let cartItem = CartItem(
                            menuItem: menuItem,
                            quantity: itemData["quantity"] as? Int ?? 1,
                            options: itemData["options"] as? [String] ?? [],
                            restaurantName: itemData["restaurantName"] as? String ?? ""
                        )
                        items.append(cartItem)
                    }
                }
                loadedOrders.append(Order(items: items, deliveryAddress: deliveryAddress, totalPrice: totalPrice, status: status))
            }
            self.orders = loadedOrders
        }
    }
    
    func saveOrdersToFirestore() {
        for order in orders {
            db.collection("orders").document(order.id).setData([
                "deliveryAddress": order.deliveryAddress,
                "totalPrice": order.totalPrice,
                "status": order.status,
                "items": order.items.map { item in
                    [
                        "name": item.menuItem.name,
                        "price": item.menuItem.price,
                        "description": item.menuItem.description,
                        "imageURL": item.menuItem.imageURL ?? "",
                        "quantity": item.quantity,
                        "options": item.options,
                        "restaurantName": item.restaurantName
                    ]
                }
            ]) { error in
                if let error = error {
                    print("Order Saving Error: \(error)")
                }
            }
        }
    }
    
    private func loadSavedAddress() {
        guard let uid = Auth.auth().currentUser?.uid else { return }
        db.collection("users").document(uid).getDocument { snapshot, error in
            if let error = error {
                print("Load Address Error: \(error)")
                return
            }
            if let data = snapshot?.data(), let savedStreet = data["savedAddress.street"] as? String {
                address = Address(street: savedStreet, validated: false, eta: 0, fee: 0.0)
            }
        }
    }
    
    private func saveAddressToFirestore() {
        guard let uid = Auth.auth().currentUser?.uid else { return }
        db.collection("users").document(uid).updateData([
            "savedAddress.street": address.street
        ]) { error in
            if let error = error {
                print("Load Address Error: \(error)")
            }
        }
    }
    
    private var ordersView: some View {
        List {
            ForEach(orders) { order in
                VStack(alignment: .leading, spacing: 8) {
                    Text("Order ID: \(order.id.prefix(8))...")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                    
                    Text("Status: \(order.status.capitalized)")
                        .font(.title3)
                        .fontWeight(.bold)
                        .foregroundColor(order.status == "paid" ? .green : .orange)
                    
                    Text("Total: $\(order.totalPrice, specifier: "%.2f")")
                        .font(.title3)
                        .fontWeight(.semibold)
                }
                .padding(.vertical, 8)
                .contentShape(Rectangle())
                .onTapGesture {
                    selectedOrderForDetail = order
                }
            }
        }
        .navigationTitle("My Orders")
        .sheet(item: $selectedOrderForDetail) { order in
            OrderDetailView(order: order,
                            onPay: {
                selectedPendingOrder = order
                showPayment = true
            })
        }
    }
    
    private func submitReview(for order: Order) {
        print("Review submitted for order \(order.id): \(rating) stars – \(review)")
    }
    
    private var paymentView: some View {
        VStack(spacing: 30) {
            Text("Order Checkout")
                .font(.title)
                .fontWeight(.bold)
            
            // 安全取出 pending 的訂單
            if let order = selectedPendingOrder ?? orders.last(where: { $0.status == "pending" }) {
                let subtotal = order.items.reduce(0.0) { $0 + ($1.menuItem.price * Double($1.quantity)) }
                
                List {
                    Section("Order Details") {
                        ForEach(order.items) { item in
                            HStack {
                                VStack(alignment: .leading, spacing: 4) {
                                    Text(item.menuItem.name)
                                        .font(.headline)
                                    if !item.menuItem.description.isEmpty {
                                        Text(item.menuItem.description)
                                            .font(.caption)
                                            .foregroundColor(.secondary)
                                    }
                                }
                                Spacer()
                                Text("Qty:\(item.quantity) × $\(item.menuItem.price, specifier: "%.2f")")
                                    .foregroundColor(.secondary)
                            }
                        }
                    }
                    
                    Section {
                        HStack {
                            Text("Subtotal")
                            Spacer()
                            Text("$\(subtotal, specifier: "%.2f")")
                                .foregroundColor(.secondary)
                        }
                        
                        HStack {
                            Text("Delivery Fee")
                            Spacer()
                            Text("$\(order.deliveryFee, specifier: "%.2f")")
                                .foregroundColor(.secondary)
                        }
                        
                        HStack {
                            Text("Total")
                                .font(.title3)
                                .fontWeight(.bold)
                            Spacer()
                            Text("$\(order.totalPrice, specifier: "%.2f")")
                                .font(.largeTitle)
                                .fontWeight(.bold)
                                .foregroundColor(.blue)
                        }
                    }
                }
                .listStyle(.insetGrouped)
            } else {
                Text("Orders awaiting payment cannot be found")
                    .foregroundColor(.red)
            }
            
            VStack(spacing: 16) {
                Button("Confirm Payment (3D Secure Simulation)") {
                    paymentSuccess = true
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                        payForPendingOrder()
                    }
                }
                .buttonStyle(.borderedProminent)
                .controlSize(.large)
                
                if paymentSuccess {
                    Label("Payment Successful!", systemImage: "checkmark.circle.fill")
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundColor(.green)
                }
            }
        }
        .padding()
        .onDisappear {
            dismissPaymentAndResetAll()
        }
    }
    
    private func onSuccess() {
        if let lastIndex = orders.indices.last {
            orders[lastIndex].status = "paid"
            saveOrdersToFirestore()
        }
        dismissPaymentAndResetAll()
        alertTitle = "Success"
        alertMessage = "Order placed successfully! Thank you for your purchase."
        showAlert = true
    }
    
    private func payForPendingOrder() {
        if let pendingOrder = selectedPendingOrder,
           let index = orders.firstIndex(where: { $0.id == pendingOrder.id }) {
            orders[index].status = "paid"
            saveOrdersToFirestore()
        }
        else if let lastIndex = orders.indices.last {
            orders[lastIndex].status = "paid"
            saveOrdersToFirestore()
        }

        dismissPaymentAndResetAll()
        alertTitle = "Success"
        alertMessage = "Payment successful! Your order is now paid."
        showAlert = true
    }
    
    private func dismissPaymentAndResetAll() {
        tabSelection = 3
        cart.removeAll()
        couponCode = ""
        selectedPendingOrder = nil
        paymentSuccess = false
        finalPaymentAmount = 0.0
        showPayment = false
        address = Address()
    }
}

#Preview {
    ContentView()
}
