import SwiftUI
import FirebaseAuth
import FirebaseFirestore

struct LoginView: View {
    @State private var email: String = ""
    @State private var password: String = ""
    @State private var errorMessage: String = ""
    @State private var isSigningUp: Bool = false
    @Binding var user: User?
    let onLogin: () -> Void
    
    let db = Firestore.firestore()
    
    var body: some View {
        VStack {
            Text("Food Ordering App Login")
                .font(.largeTitle)
                .padding()
            
            TextField("Email", text: $email)
                .textFieldStyle(.roundedBorder)
                .padding()
            
            SecureField("Password", text: $password)
                .textFieldStyle(.roundedBorder)
                .padding()
            
            if !errorMessage.isEmpty {
                Text(errorMessage)
                    .foregroundColor(.red)
                .padding()
            }
            
            Button(isSigningUp ? "Register" : "Login") {
                if isSigningUp {
                    signUp()
                } else {
                    signIn()
                }
            }
            .padding()
            .background(Color.blue)
            .foregroundColor(.white)
            .cornerRadius(8)
            
            Button("Switch to \(isSigningUp ? "Login" : "Register")") {
                isSigningUp.toggle()
            }
            .padding()
        }
    }
    
    func signUp() {
        Auth.auth().createUser(withEmail: email, password: password) { authResult, error in
            if let error = error {
                errorMessage = error.localizedDescription
                return
            }
            if let authUser = authResult?.user {
                db.collection("users").document(authUser.uid).setData([
                    "email": email,
                    "role": UserRole.customer.rawValue
                ]) { err in
                    if let err = err {
                        errorMessage = "Firestore error: \(err.localizedDescription)"
                    } else {
                        user = authUser
                        onLogin()
                    }
                }
            }
        }
    }
    
    func signIn() {
        Auth.auth().signIn(withEmail: email, password: password) { authResult, error in
            if let error = error {
                errorMessage = error.localizedDescription
                return
            }
            user = authResult?.user
            onLogin()
        }
    }
}

#Preview {
    LoginView(user: .constant(nil), onLogin: {})
}
